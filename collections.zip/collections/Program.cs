﻿using System;
using System.Collections.Generic;
namespace collections
{
    class Program
    {
        static void Main(string[] args)
        {
            /* 0 to 9 just int */
            int[] numbers = new int[10];
             for (int i = 0; i < numbers.Length; i++)
             {
                     numbers[i] = i;
                     Console.WriteLine(numbers[i]);
                 
             }

             /*  String array */
            string[] names = new string[]
            {
                "Tim", "Martin", "Nikki", "Sara"
            };
            foreach (var item in names)
            {
                Console.WriteLine(item);
            }
            
            
            /* True/False values     */
            bool[] myarr = new bool[10]
            {
                true, false, true, false, true, false, true, false, true, false
            };
            foreach (var item in myarr)
            {
                Console.WriteLine(item);
            }

        // int[] x = new int[11];
         
         
         /* Multiplication Table     */
        // int[,] multiplication = new int[10, 10];
        // for(int valx = 1; valx < 10; valx++)
        // {
        //     for(int valy = 1; valy <10; valy++)
        //     {
        //         multiplication[valx-1, valy-1] = valx * valy;
        //     }
        // }
        

           /* Multiplication table */
             int[,] table= new int[10,10];
             for(int x = 0; x < 10; x++)
             {
                 for(int y = 0; y < 10; y++)
                 {
                     table[x, y] = (x + 1) * (y + 1);
                 }
             }
             for(int x = 0; x < 10; x++)
             {
                 string display = "[ "; 
                 for(int y = 0; y < 10; y++)
                 {
                     display += table[x, y] + " ";
                     if(table[x,y] < 10)
                     {
                         display += " ";
                     }
                 }
                 display += "]";
                 
                 Console.WriteLine(display);
             }
        
        /*List of Flavors */
    
        List<string>Icecream = new List<string>();
        Icecream.Add("Chocolate");
        Icecream.Add("Vanilla");
        Icecream.Add("Blue Moon");
        Icecream.Add("Strawberry");
        Icecream.Add("Caramel");
        Console.WriteLine("Total Flavor's {0}", Icecream.Count);
        Console.WriteLine(Icecream[2]);
        Icecream.RemoveAt(2);
        Console.WriteLine("Total Flavor's now {0}", Icecream.Count);
    
       /*Dictionary */
    /*
       Dictionary <string, string> language = new Dictionary<string, string>();
        language.Add("Australia", "English");
        language.Add("Czech Republic", "Czech");
        language.Add("Germany", "German");
        language.Add("Japan", "Japanese");
        foreach(KeyValuePair<string, string> entry in language)
        {
            Console.WriteLine(entry.Key + " --> " + entry.Value);
        }*/


       Dictionary <string, string> Flavors = new Dictionary<string, string>();
       Random diff = new Random();
       foreach (string name in names)
       {
           Flavors[name] = Icecream[diff.Next(Flavors.Count)];
       }
        foreach(KeyValuePair<string, string>data in Flavors)
        {
            Console.WriteLine(data.Key + "- " + data.Value);
        }
        }
    }
}
