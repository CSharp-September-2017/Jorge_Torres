﻿using System;

namespace fundamentals
{
    class Program
    {
        static void Main(string[] args)
        {
        //    for (int var = 1; var <= 255; var++)
        //    {
        //        Console.WriteLine(var);
        //    }
        /* ********************************************** */
        //    for (int i = 1; i <= 100; i++)
        //    {
        //        Console.WriteLine("Num:{0}",i);
        //    }
        /* ////////////////////////////////////////// */
        // for (int var = 1; var <= 255; var++)
        //    {
        //        if( var % 3 == 0)
        //        {
        //            Console.WriteLine("Fizz {0}", var);
        //        }
        //        else if ( var % 5 == 0)
        //        {
        //            Console.WriteLine("Buzz {0}", var);
        //        }
        //        else if (var % 3 ==0 && var % 5 == 0)
        //        {
        //            Console.WriteLine("FizzBuzz {0}", var);
        //        }
        //     //    Console.WriteLine(var);
        //         else
        //         {
        //             Console.WriteLine("Num: {0}", var);
        //         }
        //    }

    /*============================================= */

           Random rand = new Random();
            for (int num = 0; num <= 10; num++)
            {
                
                int val = rand.Next(1, 100);

                if(val % 3 == 0 && val % 5 == 0)
                {
                    Console.WriteLine("FizzBuzz");
                }
                else if (val % 3 == 0)
                {
                    Console.WriteLine("Fizz");
                }
                else if (val % 5 == 0)
                {
                   Console.WriteLine("Buzz");
                } else {
                    Console.WriteLine(val);
                }

            }

        }
    }
}
